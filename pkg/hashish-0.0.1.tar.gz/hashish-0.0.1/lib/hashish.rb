module Hashish
  def hashish
    "Hashish is good."
  end
end

class String  
  include Hashish  
end